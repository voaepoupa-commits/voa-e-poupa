# VOA & POUPA

Site estático em português de Portugal, preparado para o repositório privado `voaepoupa-commits/voa-e-poupa`. Não precisa de instalação, conta, chave de API ou compilação.

## Ver o site no computador

1. Extrai o ZIP para uma pasta.
2. Abre o ficheiro **index.html** com o Edge, Chrome, Firefox ou Safari.
3. Mantém `styles.css`, `app.js` e a pasta `assets` junto de `index.html`.
4. A página e as ilustrações funcionam sem Internet. Para pesquisar voos, é necessária uma ligação à Internet.

## Colocar no repositório privado, sem publicar

1. Guarda uma cópia dos ficheiros atuais do repositório.
2. Abre https://github.com/voaepoupa-commits/voa-e-poupa e confirma que aparece **Private**.
3. Cria uma nova branch no seletor onde aparece `main`, por exemplo `site-moderno`.
4. Escolhe **Add file → Upload files**. Arrasta o conteúdo desta pasta para a raiz do repositório: `index.html`, `styles.css`, `app.js`, `assets/`, `README.md`, `.gitignore` e `.nojekyll`. Não carregues a pasta exterior nem o ZIP.
5. Guarda as alterações na nova branch. Se o GitHub não aceitar substituir um ficheiro existente, abre esse ficheiro, escolhe o lápis de edição e substitui o conteúdo pelo ficheiro correspondente deste pacote.
6. Compara a branch com `main` e revê os ficheiros antes de integrar as alterações. Se já existir publicação automática configurada, integrar em `main` pode publicar o site: confirma primeiro essa configuração.

**Este pacote não ativa o GitHub Pages, não publica o site, não envia alterações ao GitHub e não altera a privacidade do repositório.** Uma eventual publicação deve ser decidida separadamente. Um site publicado pode ficar acessível ao público mesmo quando os ficheiros de origem estão num repositório privado; verifica o acesso antes de autorizar qualquer publicação.

## O que está incluído

- Logótipo vetorial original com globo e avião; paleta azul-marinho, azul e laranja.
- Página adaptada a telemóvel, tablet e computador.
- Destinos Lisboa–Luanda, Lisboa–Paris, Lisboa–Rio de Janeiro e Lisboa–Ilha do Sal.
- Os botões dos destinos preenchem a pesquisa e levam-te às datas.
- Pesquisa com origem, destino, ida, volta opcional e 1 a 6 passageiros adultos, em económica.
- Verificação de campos obrigatórios, datas e origem/destino iguais.
- Dicas de viagem, informação sobre ligações externas e ligação ao site oficial da TAP.
- Navegação por teclado, ligação para saltar o menu, foco visível e respeito pela preferência de movimento reduzido.

## Como funciona a pesquisa

O formulário abre `https://www.google.com/travel/flights` num novo separador com uma consulta que inclui os campos escolhidos. Usa uma consulta textual, não uma API de reservas. A interpretação dos campos depende do Google Flights: **confirma origem, aeroportos, datas, passageiros e tipo de viagem no serviço externo**. Paris e Rio usam a cidade, incluindo os seus aeroportos. Não há promessa de voos diretos, disponibilidade ou tarifas. A pesquisa serve adultos; outras idades devem ser configuradas no serviço externo.

Sem JavaScript, existe uma ligação direta ao Google Flights. Não são apresentados preços, resultados simulados ou promoções fictícias. Não existe relação comercial ou afiliação declarada com Google ou TAP.

## Alterar textos e imagens

- Textos e destinos: `index.html`.
- Cores e disposição: `styles.css` (cores no início do ficheiro).
- Pesquisa e validação: `app.js`.
- Logótipo: `assets/logo.svg`. Ilustração do hero: `assets/mundo.svg`.
- Ilustrações dos destinos: vetores e formas em `index.html` e `styles.css`, sem fotografias remotas ou dependências externas.

As ilustrações foram criadas para este pacote. A imagem aprovada na conversa anterior não estava disponível na recuperação; a implementação segue a descrição fornecida, sem afirmar reprodução exata dessa imagem.

## Antes de uma futura publicação

Experimenta a página no telemóvel e no computador. Testa ida e volta, só ida, cada destino, origem igual ao destino e datas inválidas. Confirma os dados após abrir o Google Flights. Revê o nome e os textos da marca. Define contactos e informação adicional da entidade responsável caso venhas a acrescentar formulários, vendas, análise de visitas ou outros serviços.

O site não guarda dados, não instala cookies próprios e não inclui análise de visitas. Os dados da pesquisa são enviados ao Google apenas ao carregar em Pesquisar; os sites externos têm as suas próprias políticas. Não foram incluídos contactos, testemunhos ou números de clientes inventados.

## Atualização visual — versão 2
O destaque usa agora assets/viagens-profissional.png: imagem gerada por IA, com um avião e uma montagem artística dos destinos. Não representa uma vista geográfica real. A ilustração vetorial anterior continua disponível em assets/mundo.svg. Imagem criada com a ferramenta integrada de geração de imagens.

## Atualização visual — versão 3
O destaque atual usa assets/aviao-lisboa.png, criado com a ferramenta integrada de geração de imagens: avião sobre Lisboa e o Tejo, numa única cena de aspeto fotográfico. É uma imagem gerada por IA, não uma fotografia documental.
