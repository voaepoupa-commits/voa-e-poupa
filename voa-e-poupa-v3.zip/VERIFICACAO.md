# Verificação desta entrega

- JavaScript: verificação de sintaxe concluída com sucesso.
- Página local: resposta HTTP 200.
- Apresentação no navegador de computador: verificada visualmente, incluindo logótipo, hero e formulário.
- Botão Lisboa–Paris: seleciona Paris e leva o foco à data de ida.
- Só ida: oculta e desativa o campo de regresso.
- Origem e destino iguais: apresenta o aviso e impede a pesquisa.
- Pesquisa válida: abre um novo separador do Google Flights com origem, destino, data, só ida e passageiros na consulta.
- A interpretação final dos campos pelo Google Flights e as tarifas não foram verificadas; confirma os dados no serviço externo.
- O CSS inclui adaptações a ecrãs pequenos; não foi feita verificação visual num dispositivo móvel nesta sessão.
- Sem publicação, envio para o GitHub ou alteração da privacidade do repositório.
